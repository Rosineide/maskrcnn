# Alitas - TCC_H > 2023-04-26 11:46am
https://universe.roboflow.com/medusas/alitas-tcc_h

Provided by a Roboflow user
License: CC BY 4.0

